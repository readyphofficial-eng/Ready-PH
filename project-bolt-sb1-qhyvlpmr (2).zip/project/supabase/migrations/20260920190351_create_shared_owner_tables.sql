/*
# Create shared owner data tables (single-tenant, no auth)

This migration creates tables so that data the owner (Jayden) sets in the Owner Dashboard
is shared across ALL users — not just the owner's browser. The app has no sign-in screen,
so all policies use `TO anon, authenticated` (the anon-key client can read and write).

## New Tables

1. `app_config` — single-row table holding global settings:
   - `id` (int, always 1) — singleton key
   - `logo` (text) — base64 data URL of the app logo
   - `yt_channel_name` (text) — YouTube channel display name
   - `yt_channel_id` (text) — YouTube channel ID for RSS feed
   - `sponsored_brand` (text) — sponsored lesson brand
   - `sponsored_title` (text) — sponsored lesson title
   - `sponsored_url` (text) — sponsored lesson URL
   - `updated_at` (timestamptz) — last modification time

2. `partners` — partner logos shown on Partners page and Shop page:
   - `id` (uuid, PK)
   - `name` (text)
   - `logo` (text) — emoji fallback
   - `logo_img` (text) — base64 data URL image
   - `sort_order` (int) — display order
   - `created_at` (timestamptz)

3. `shop_items` — online shop items shown on Shop page:
   - `id` (uuid, PK)
   - `logo` (text) — emoji fallback
   - `logo_img` (text) — base64 data URL image
   - `title` (text)
   - `desc` (text)
   - `sub_desc` (text)
   - `link` (text)
   - `sort_order` (int)
   - `created_at` (timestamptz)

4. `manual_videos` — owner-added YouTube videos:
   - `id` (uuid, PK)
   - `title` (text)
   - `url` (text)
   - `category` (text)
   - `description` (text)
   - `date` (text) — ISO date string
   - `sort_order` (int)
   - `created_at` (timestamptz)

5. `support_media` — support page images:
   - `id` (uuid, PK)
   - `image_data` (text) — base64 data URL
   - `sort_order` (int)
   - `created_at` (timestamptz)

6. `dev_messages` — messages sent by users to the developer:
   - `id` (uuid, PK)
   - `name` (text)
   - `message` (text)
   - `date` (text) — ISO date string
   - `created_at` (timestamptz)

## Security

All tables have RLS enabled. Since this is a no-auth single-tenant app where data is
intentionally shared across all users, all policies use `TO anon, authenticated` with
`USING (true)` / `WITH CHECK (true)` — the data is public by design.

## Important Notes

1. The `app_config` table is a singleton (id = 1). The app upserts row id=1.
2. All images are stored as base64 data URLs in text columns.
3. `dev_messages` allows any user to insert (send a message) but only the owner
   reads/deletes them from the dashboard — in practice all users can read since there
   is no auth, but the UI only shows the inbox to the owner.
*/

-- app_config singleton
CREATE TABLE IF NOT EXISTS app_config (
  id int PRIMARY KEY DEFAULT 1,
  logo text DEFAULT '',
  yt_channel_name text DEFAULT '',
  yt_channel_id text DEFAULT '',
  sponsored_brand text DEFAULT '',
  sponsored_title text DEFAULT '',
  sponsored_url text DEFAULT '',
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT app_config_singleton CHECK (id = 1)
);

ALTER TABLE app_config ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_read_app_config" ON app_config;
CREATE POLICY "anon_read_app_config" ON app_config FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_write_app_config" ON app_config;
CREATE POLICY "anon_write_app_config" ON app_config FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_app_config" ON app_config;
CREATE POLICY "anon_update_app_config" ON app_config FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_app_config" ON app_config;
CREATE POLICY "anon_delete_app_config" ON app_config FOR DELETE
  TO anon, authenticated USING (true);

-- partners
CREATE TABLE IF NOT EXISTS partners (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL DEFAULT '',
  logo text DEFAULT '',
  logo_img text DEFAULT '',
  sort_order int DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE partners ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_read_partners" ON partners;
CREATE POLICY "anon_read_partners" ON partners FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_partners" ON partners;
CREATE POLICY "anon_insert_partners" ON partners FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_partners" ON partners;
CREATE POLICY "anon_update_partners" ON partners FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_partners" ON partners;
CREATE POLICY "anon_delete_partners" ON partners FOR DELETE
  TO anon, authenticated USING (true);

-- shop_items
CREATE TABLE IF NOT EXISTS shop_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  logo text DEFAULT '',
  logo_img text DEFAULT '',
  title text NOT NULL DEFAULT '',
  "desc" text DEFAULT '',
  sub_desc text DEFAULT '',
  link text DEFAULT '',
  sort_order int DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE shop_items ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_read_shop_items" ON shop_items;
CREATE POLICY "anon_read_shop_items" ON shop_items FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_shop_items" ON shop_items;
CREATE POLICY "anon_insert_shop_items" ON shop_items FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_shop_items" ON shop_items;
CREATE POLICY "anon_update_shop_items" ON shop_items FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_shop_items" ON shop_items;
CREATE POLICY "anon_delete_shop_items" ON shop_items FOR DELETE
  TO anon, authenticated USING (true);

-- manual_videos
CREATE TABLE IF NOT EXISTS manual_videos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL DEFAULT '',
  url text DEFAULT '',
  category text DEFAULT '',
  description text DEFAULT '',
  date text DEFAULT '',
  sort_order int DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE manual_videos ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_read_manual_videos" ON manual_videos;
CREATE POLICY "anon_read_manual_videos" ON manual_videos FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_manual_videos" ON manual_videos;
CREATE POLICY "anon_insert_manual_videos" ON manual_videos FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_manual_videos" ON manual_videos;
CREATE POLICY "anon_update_manual_videos" ON manual_videos FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_manual_videos" ON manual_videos;
CREATE POLICY "anon_delete_manual_videos" ON manual_videos FOR DELETE
  TO anon, authenticated USING (true);

-- support_media
CREATE TABLE IF NOT EXISTS support_media (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  image_data text DEFAULT '',
  sort_order int DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE support_media ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_read_support_media" ON support_media;
CREATE POLICY "anon_read_support_media" ON support_media FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_support_media" ON support_media;
CREATE POLICY "anon_insert_support_media" ON support_media FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_support_media" ON support_media;
CREATE POLICY "anon_update_support_media" ON support_media FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_support_media" ON support_media;
CREATE POLICY "anon_delete_support_media" ON support_media FOR DELETE
  TO anon, authenticated USING (true);

-- dev_messages
CREATE TABLE IF NOT EXISTS dev_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text DEFAULT '',
  message text DEFAULT '',
  date text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE dev_messages ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_read_dev_messages" ON dev_messages;
CREATE POLICY "anon_read_dev_messages" ON dev_messages FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_dev_messages" ON dev_messages;
CREATE POLICY "anon_insert_dev_messages" ON dev_messages FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_dev_messages" ON dev_messages;
CREATE POLICY "anon_delete_dev_messages" ON dev_messages FOR DELETE
  TO anon, authenticated USING (true);
