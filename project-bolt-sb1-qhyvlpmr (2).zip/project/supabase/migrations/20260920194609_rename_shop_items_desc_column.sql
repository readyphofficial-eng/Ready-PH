/*
# Rename shop_items.desc to shop_items.description

The column `desc` is a SQL reserved keyword and causes issues with the Supabase JS client.
Renaming it to `description` for reliable read/write operations.

1. Renamed column `desc` → `description` on `shop_items` table.
2. No data loss — same type, same values, just a new name.
*/

ALTER TABLE shop_items RENAME COLUMN "desc" TO description;
